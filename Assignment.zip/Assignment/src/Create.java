

import java.sql.*;


public class Create {
	
	 static final String DB_URL="jdbc:mysql://localhost:3306/demo";
	 static final String USER="root";
	 static final String PASS= "pass@word1";
	 static final String QUERY="create table student3 (s_id int, fname varchar(255), lname varchar(255), course varchar(255), PRIMARY KEY(s_id))";


	public static void main(String[] args) {
	
		try(Connection con = DriverManager.getConnection(DB_URL,USER,PASS);
				Statement stmt = con.createStatement();
				PreparedStatement ps = con.prepareStatement(QUERY);
				)
		{
			ps.executeUpdate();
			System.out.println("student3 table has been created successfully");	
		}
		catch(SQLException e)
		{
			
		}

	}

}

