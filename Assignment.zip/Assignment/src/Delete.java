import java.sql.*;
import java.util.Scanner;

public class Delete {

	 static final String DB_URL="jdbc:mysql://localhost:3306/demo";
	 static final String USER="root";
	 static final String PASS= "pass@word1";
	 static final String QUERY="delete from student3 where course = ?";

	public static void main(String[] args) {
		
		try(Connection con = DriverManager.getConnection(DB_URL,USER,PASS);
			Statement stmt = con.createStatement();
		    PreparedStatement ps = con.prepareStatement(QUERY);
	       )
		{
			Scanner sc = new Scanner(System.in);
			System.out.println("enter the course name of which you want to delete the student details : ");
			String course = sc.next();
			sc.nextLine();
			
			ps.setString(1, course);
			ps.executeUpdate();
			System.out.println("Records has been deleted");
		}
		catch(SQLException e)
		{
			
		}
	
	}

}
