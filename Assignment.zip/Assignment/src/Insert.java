

import java.sql.*;
import java.util.Scanner;

public class Insert {

	 static final String DB_URL="jdbc:mysql://localhost:3306/demo";
	 static final String USER="root";
	 static final String PASS= "pass@word1";
	 static final String QUERY="insert into student3(s_id, fname, lname, course) values(?,?,?,?)";

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try(Connection con = DriverManager.getConnection(DB_URL,USER,PASS);
				Statement stmt=con.createStatement();
				PreparedStatement ps = con.prepareStatement(QUERY);){
	            Scanner sc = new Scanner(System.in);
	            System.out.println("enter the number of student you want to store : ");
	            int n = sc.nextInt();
	            for(int i=0; i<n; i++)
	            {
				System.out.println("enter Student id : ");
				int id = sc.nextInt();
				
				System.out.println("enter first name : ");
				String first= sc.next();
				sc.nextLine();
				
				System.out.println("enter last name : ");
				String last = sc.next();
				sc.nextLine();
				
				System.out.println("enter course name : ");
				String course = sc.next();
				sc.nextLine();
				
				ps.setInt(1, id);
				ps.setString(2, first);
				ps.setString(3,last);
				ps.setString(4,course);
				ps.executeUpdate();
	            }
	
		}
		catch(SQLException e)
		{
			
		}
	}

}
