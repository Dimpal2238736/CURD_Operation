import java.sql.*;
import java.util.Scanner;

public class Search {

	 static final String DB_URL="jdbc:mysql://localhost:3306/demo";
	 static final String USER="root";
	 static final String PASS= "pass@word1";
	static final String QUERY="select * from student3 where s_id=?";
	 
	public static void main(String[] args) {
	
		try
		{
			Connection con = DriverManager.getConnection(DB_URL, USER, PASS);
			Statement stmt = con.createStatement();
			PreparedStatement ps = con.prepareStatement(QUERY);
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the student id to get the student details : ");
			int id = sc.nextInt();
			
			ps.setInt(1, id);
			//ps.executeUpdate();
			ResultSet rs = ps.executeQuery();
		
			while(rs.next())
			{
			System.out.println("First name : "+rs.getString("fname"));
			System.out.println("Last name : "+rs.getString("lname"));
			System.out.println("Course name : "+rs.getString("course"));
		    }
		}
        catch(SQLException e)
		{
        	
		}
	}

}
