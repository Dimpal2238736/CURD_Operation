package oops;

class Employee
{
	private int id;
	private String empName;
	private String empAdd;
	private long salary;
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Employee(int id, String empName, String empAdd, long salary) {
		super();
		this.id = id;
		this.empName = empName;
		this.empAdd = empAdd;
		this.salary = salary;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpAdd() {
		return empAdd;
	}
	public void setEmpAdd(String empAdd) {
		this.empAdd = empAdd;
	}
	public long getSalary() {
		return salary;
	}
	public void setSalary(long salary) {
		this.salary = salary;
	}	
	
}
public class Encapsulation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee emp = new Employee(2345, "Rakesh", "Banglore", 550000);
		System.out.println(emp.getEmpName());
		System.out.println(emp.getSalary());

	}

}
