package oops;

abstract class Mobile
{
    public abstract void model();
    
    public void info()
    {
    	System.out.println("I am abstract class Mobile");
    }
}

class Redmi extends Mobile
{
    public void color()
    {
       System.out.println("Color : Black");
    }
	
	@Override
	public void model() {
		// TODO Auto-generated method stub
		 System.out.println("Model : Redmi Note 11 Pro");
	}
	
}
public class Abstraction 
{
     public static void main(String args[])
     {
    	 Redmi obj = new Redmi();
    	 obj.info();
    	 obj.color();
    	 obj.model();
     }
}


