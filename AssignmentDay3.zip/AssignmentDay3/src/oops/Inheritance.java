package oops;

class ParentClass
{
	public void func1()
	{
		System.out.println("inside parent class method");
	}
}
class SubClass1 extends ParentClass
{
	public void func2()
	{
		System.out.println("inside sub class 1 extended by parent class");
	}
}
class SubClass2 extends SubClass1
{
	public void func3()
	{
		System.out.println("inside sub class 2 extended by sub class 1");
	}
}
public class Inheritance {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
       SubClass2 obj = new SubClass2();
       obj.func1();
       obj.func2();
       obj.func3();
	}

}
