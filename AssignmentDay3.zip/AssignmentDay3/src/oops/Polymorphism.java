package oops;

class Subjects
{
	public void science()
	{
		System.out.println("Science Subject");
	}
	public void science(String str)
	{
		String str1=str;
		System.out.println("science subject with sub category : "+str1);
	}
}
class GeneralSubject extends Subjects
{
	@Override
	public void science()
	{
		System.out.println("General Subject");
	}
}
public class Polymorphism {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
        Subjects sobj = new Subjects();
        sobj.science();
        sobj=new GeneralSubject();
        sobj.science();
	}

}
