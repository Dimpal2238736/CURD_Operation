package java8;

interface FunctionalInterface
{
	void function();
}
public class LambdaExpression {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       FunctionalInterface fi = ()-> System.out.println("Functional Interface Implemented by Lambda Expression");
       fi.function();
	}

}
