package java8;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamAPI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      List<Integer> list = List.of(56,76,22,54,12,15,99);
      List<Integer> evenNumberList = list.stream()
    		                             .filter(e->e%2==0)
    		                             .collect(Collectors.toList());
     System.out.println("even number from list : "+evenNumberList);
     
     List<Integer> updatedList = list.stream()
                                     .map(e->e+2)
                                     .collect(Collectors.toList());
     System.out.println("updated list : "+updatedList);
     
     Stream<Integer> sortedList = list.stream().sorted();
     System.out.println("Sorted List : ");
     sortedList.forEach(i->System.out.println(i));
     
     long count = list.stream().count();
     System.out.println("Total elements of the list : "+count);
    
	}

}
