package validationPages;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class LoginPage {

	static final String DB_URL = "jdbc:mysql://localhost:3306/demo";
	static final String USER = "root";
	static final String PASS = "pass@word1";
	static final String QUERY = "select email, password from newuser where email=? AND password=?";

	public static void main(String args[]) {

		try  {
			Connection con = DriverManager.getConnection(DB_URL, USER, PASS);
			Statement stmt = con.createStatement();
			PreparedStatement ps = con.prepareStatement(QUERY);
			

			Scanner sc = new Scanner(System.in);
			System.out.print("enter email : ");
			String email = sc.nextLine();

			System.out.print("enter password : "); 
			String pwd = sc.nextLine();
			
			ps.setString(1, email);
		    ps.setString(2, pwd);
			
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()) {
				   System.out.println("logged In");
				}
				else 
				{
					System.out.println("No User Found");
				}
			

		} catch (SQLException e) {

		}
	}

}
