package validationPages;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class RegistrationPage {

	static final String DB_URL="jdbc:mysql://localhost:3306/demo";
	 static final String USER="root";
	 static final String PASS= "pass@word1";
	 static final String QUERY="insert into newuser (name, email, password) values (?,?,?)";

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try(Connection con = DriverManager.getConnection(DB_URL,USER,PASS);
				Statement stmt = con.createStatement();
				PreparedStatement ps = con.prepareStatement(QUERY);
				)
		{
			    Scanner sc = new Scanner(System.in);
	            System.out.println("Create an Account");
	          
				
				System.out.println("enter name : ");
				String name= sc.nextLine();
				
				
				System.out.println("enter email : ");
				String email = sc.nextLine();
				
				
				System.out.println("enter password : ");
				String pwd = sc.nextLine();
				
				ps.setString(1,name);
				ps.setString(2,email);
				ps.setString(3,pwd);
			    ps.executeUpdate();
			    System.out.println("Registration Completed");
		}
		catch(SQLException e)
		{
			
		}

	}

}
